<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" 
    xmlns:regexp="http://exslt.org/regular-expressions"
    xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2" 
    xmlns:ds="http://www.w3.org/2000/09/xmldsig#" 
    xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" 
    xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1"
    xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" 
    xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" 
    xmlns:dp="http://www.datapower.com/extensions" 
    extension-element-prefixes="dp" exclude-result-prefixes="dp" version="1.0">
    <!-- xsl:include href="../../../commons/error/validate_utils.xsl" dp:ignore-multiple="yes" / -->
    <xsl:include href="local:///commons/error/validate_utils.xsl" dp:ignore-multiple="yes" />
    
    <!-- key Documentos Relacionados Duplicados -->
    <xsl:key name="by-document-despatch-reference" match="*[local-name()='DebitNote']/cac:DespatchDocumentReference" use="concat(cbc:DocumentTypeCode,' ', cbc:ID)"/>
    
    <xsl:key name="by-document-additional-reference" match="*[local-name()='DebitNote']/cac:AdditionalDocumentReference" use="concat(cbc:DocumentTypeCode,' ', cbc:ID)"/>
    
    <!-- key Numero de lineas duplicados fin -->
    <xsl:key name="by-invoiceLine-id" match="*[local-name()='DebitNote']/cac:DebitNoteLine" use="number(cbc:ID)"/>
    
    <!-- key tributos duplicados por linea -->
    <xsl:key name="by-tributos-in-line" match="cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal" use="concat(cac:TaxCategory/cac:TaxScheme/cbc:ID,'-', ../../cbc:ID)"/>
    
    <!-- key tributos duplicados por cabecera -->
    <xsl:key name="by-tributos-in-root" match="*[local-name()='DebitNote']/cac:TaxTotal/cac:TaxSubtotal" use="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
    
    <!-- key AdditionalMonetaryTotal duplicados -->
    <xsl:key name="by-AdditionalMonetaryTotal" match="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal" use="cbc:ID"/>
    
    <xsl:key name="by-Billingreference" match="cac:BillingReference/cac:InvoiceDocumentReference" use="concat(cbc:DocumentTypeCode, cbc:ID)"/>
    
    <xsl:template match="/*">
    
        <!-- 
        ===========================================================================================================================================
        Variables  
        ===========================================================================================================================================
        -->
        <!-- Validando que el nombre del archivo coincida con la informacion enviada en el XML -->
        
        <xsl:variable name="numeroRuc" select="substring(dp:variable('var://context/cpe/nombreArchivoEnviado'), 1, 11)"/>
        
        <xsl:variable name="numeroSerie" select="substring(dp:variable('var://context/cpe/nombreArchivoEnviado'), 16, 4)"/>
        
        <xsl:variable name="tipoComprobante">
            <xsl:choose>
                <xsl:when test="substring($numeroSerie, 1, 1) = 'F' ">
                    <xsl:value-of select="'01'"/>
                </xsl:when>
                <xsl:when test="substring($numeroSerie, 1, 1) = 'S' ">
                    <xsl:value-of select="'14'"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'03'"/>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>
        
        <xsl:variable name="numeroComprobante" select="substring(dp:variable('var://context/cpe/nombreArchivoEnviado'), 21, string-length(dp:variable('var://context/cpe/nombreArchivoEnviado')) - 24)"/>
        
        <xsl:variable name="monedaComprobante" select="cbc:DocumentCurrencyCode/text()"/>
        
        <!-- 
        ===========================================================================================================================================
        Variables  
        ===========================================================================================================================================
        -->
        
        <!-- Numero de RUC del nombre del archivo no coincide con el consignado en el contenido del archivo XML -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'1034'" />
            <xsl:with-param name="node" select="cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID" />
            <xsl:with-param name="expresion" select="$numeroRuc != cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID" />
        </xsl:call-template>
        
        <!-- Numero de Serie del nombre del archivo no coincide con el consignado en el contenido del archivo XML -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'1035'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="$numeroSerie != substring(cbc:ID, 1, 4)" />
        </xsl:call-template>
        
        <!-- Numero de documento en el nombre del archivo no coincide con el consignado en el contenido del XML -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'1036'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="$numeroComprobante != substring(cbc:ID, 6)" />
        </xsl:call-template>
    
        <!-- 
        ===========================================================================================================================================
        
        Datos de la Nota de debito  
        
        ===========================================================================================================================================
        -->
        
        <!-- /DebitNote/cbc:UBLVersionID No existe el Tag UBL
        ERROR 2075 -->
        
        <!-- /DebitNote/cbc:UBLVersionID El valor del Tag UBL es diferente de "2.0"
        ERROR 2074 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2075'"/>
            <xsl:with-param name="errorCodeValidate" select="'2074'"/>
            <xsl:with-param name="node" select="cbc:UBLVersionID"/>
            <xsl:with-param name="regexp" select="'^(2.0)$'"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cbc:CustomizationID No existe el Tag UBL
        ERROR 2073 -->
        
        <!-- /DebitNote/cbc:CustomizationID El valor del Tag UBL es diferente de "1.0"
        ERROR 2072 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2073'"/>
            <xsl:with-param name="errorCodeValidate" select="'2072'"/>
            <xsl:with-param name="node" select="cbc:CustomizationID"/>
            <xsl:with-param name="regexp" select="'^(1.0)$'"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DiscrepancyResponse Existe más de un Tag UBL en el /DebitNote
        ERROR 2415 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2415'" />
            <xsl:with-param name="node" select="cac:DiscrepancyResponse" />
            <xsl:with-param name="expresion" select="count(cac:DiscrepancyResponse)>1" />
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DiscrepancyResponse/cbc:ReferenceID No existe el Tag UBL
        ERROR 2171 -->
        
        <!-- /DebitNote/cac:DiscrepancyResponse/cbc:ReferenceID El valor del Tag UBL es vacío
        ERROR 2170 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2171'"/>
            <xsl:with-param name="errorCodeValidate" select="'2170'"/>
            <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
            <xsl:with-param name="regexp" select="'^((?!\s*$)[^\s].*)$'"/>
            <!-- Ini PAS20171U210300071 -->
			<xsl:with-param name="isError" select ="false()"/>
			<!-- Fin PAS20171U210300071 -->
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DiscrepancyResponse/cbc:ResponseCode No existe el Tag UBL o es vacío
        ERROR 2173 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2173'"/>
            <xsl:with-param name="errorCodeValidate" select="'2173'"/>
            <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ResponseCode"/>
            <xsl:with-param name="regexp" select="'^((?!\s*$)[^\s].*)$'"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DiscrepancyResponse/cbc:ResponseCode El Tag UBL no existe en el listado
        ERROR 2172 -->
        <xsl:call-template name="findElementInCatalog">
            <xsl:with-param name="catalogo" select="'10'"/>
            <xsl:with-param name="idCatalogo" select="cac:DiscrepancyResponse/cbc:ResponseCode"/>
            <xsl:with-param name="errorCodeValidate" select="'2172'"/>
        </xsl:call-template>
        
        <xsl:choose>
        
            <!-- /DebitNote/cac:DiscrepancyResponse/cbc:ReferenceID "Si el ""Código de tipo de nota de débito"" es diferente de 03, el formato del Tag UBL es diferente: 
            Para notas de debito de Factura ^(([F][A-Z0-9]{3}-[0-9]{1,8})|((E001)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8})|([0-9]{1,8}))$ 
            ERROR 2170 -->
            
            
            <xsl:when test="$tipoComprobante = '01' and cac:DiscrepancyResponse/cbc:ResponseCode != '03'">
            
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2171'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2170'"/>
                    <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
                    <xsl:with-param name="regexp" select="'^(([F][A-Z0-9]{3}-[0-9]{1,8})|((E001)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8})|(--[0-9]{1,8}))$'"/>
                    <!-- Ini PAS20171U210300071 -->
					<xsl:with-param name="isError" select ="false()"/>
					<!-- Fin PAS20171U210300071 -->
                </xsl:call-template>
                
            </xsl:when>
            
            <!-- /DebitNote/cac:DiscrepancyResponse/cbc:ReferenceID "Si el ""Código de tipo de nota de débito"" es diferente de 03, el formato del Tag UBL es diferente: 
            Para notas de debito de Boleta  ^(([B][A-Z0-9]{3}-[0-9]{1,8})|((EB01)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8})|([0-9]{1,8}))$
            ERROR 2170 -->
            <xsl:when test="$tipoComprobante = '03' and cac:DiscrepancyResponse/cbc:ResponseCode != '03'">
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2171'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2170'"/>
                    <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
                    <xsl:with-param name="regexp" select="'^(([B][A-Z0-9]{3}-[0-9]{1,8})|((EB01)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8})|(--[0-9]{1,8}))$'"/>
                    <!-- Ini PAS20171U210300071 -->
					<xsl:with-param name="isError" select ="false()"/>
					<!-- Fin PAS20171U210300071 -->
                </xsl:call-template>                
            </xsl:when>
            
            <!-- /DebitNote/cac:DiscrepancyResponse/cbc:ReferenceID "Si el ""Código de tipo de nota de débito"" es diferente de 14, el formato del Tag UBL es diferente: 
            Para notas de debito de servicios publicos  ^(([B][A-Z0-9]{3}-[0-9]{1,8})|((EB01)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8})|([0-9]{1,8}))$
            ERROR 2170 -->
            <xsl:when test="$tipoComprobante = '14' and cac:DiscrepancyResponse/cbc:ResponseCode != '03'">
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2171'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2170'"/>
                    <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
                    <xsl:with-param name="regexp" select="'^(([S][A-Z0-9]{3}-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8})|(--[0-9]{1,8}))$'"/>
                    <!-- Ini PAS20171U210300071 -->
					<xsl:with-param name="isError" select ="false()"/>
					<!-- Fin PAS20171U210300071 -->
                </xsl:call-template>                
            </xsl:when>
            
        </xsl:choose>
        
        <!-- /DebitNote/cbc:DocumentCurrencyCode No existe el Tag UBL
        ERROR 2070 -->
        
        <!-- /DebitNote/cbc:DocumentCurrencyCode El formato del Tag UBL es diferente a alfabético de 3 caracteres
        ERROR 2069 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2070'"/>
            <xsl:with-param name="errorCodeValidate" select="'2071'"/>
            <xsl:with-param name="node" select="cbc:DocumentCurrencyCode"/>
            <xsl:with-param name="regexp" select="'^([\w\d]{3})$'"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cbc:DocumentCurrencyCode La moneda de los totales de línea y totales de comprobantes es diferente al valor del Tag UBL
        ERROR 2071 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2071'" />
            <xsl:with-param name="node" select="descendant::*[@currencyID != $monedaComprobante and not(ancestor-or-self::sac:AdditionalMonetaryTotal[cbc:ID='2001' or cbc:ID='2003'])]/@currencyID" />
            <xsl:with-param name="expresion" select="descendant::*[@currencyID != $monedaComprobante and not(ancestor-or-self::sac:AdditionalMonetaryTotal[cbc:ID='2001' or cbc:ID='2003'])]" />
        </xsl:call-template>
        
        <!-- 
        ===========================================================================================================================================
        
        Fin Datos de la Nota de debito
        
        ===========================================================================================================================================
        -->
        
        
        <!-- 
        ===========================================================================================================================================
        
        Datos del Emisor
        
        ===========================================================================================================================================
        -->
        
        <xsl:apply-templates select="cac:AccountingSupplierParty"/>
        
        <!-- 
        ===========================================================================================================================================
        
        Fin Datos del Emisor
        
        ===========================================================================================================================================
        --> 
        
        <!-- 
        ===========================================================================================================================================
        
        Datos del cliente o receptor
        
        ===========================================================================================================================================
        -->
        
        <xsl:apply-templates select="cac:AccountingCustomerParty">
            <xsl:with-param name="root" select="."/>
            <xsl:with-param name="tipoComprobante" select="$tipoComprobante"/>
        </xsl:apply-templates>
        
        <!-- 
        ===========================================================================================================================================
        
        fin Datos del cliente o receptor
        
        ===========================================================================================================================================
        -->
        
        <!-- 
        ===========================================================================================================================================
        
        Documentos de referencia
        
        ===========================================================================================================================================
        -->
        <!-- /DebitNote/cac:DiscrepancyResponse/cbc:Description No existe el Tag UBL
        ERROR 2136 -->
                
        <!-- /DebitNote/cac:DiscrepancyResponse/cbc:Description El formato del Tag UBL es diferente a alfanumérico de 1 hasta 250 caracteres
        ERROR 2135 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2136'"/>
            <xsl:with-param name="errorCodeValidate" select="'2135'"/>
            <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:Description"/>
			<!-- PAS20181U210300051 jas 170718 incluye espacios en blanco al comienzo y {.}  -->
            <!--<xsl:with-param name="regexp" select="'^(?!\s*$)[^\s].{1,249}$'"/>-->
			<xsl:with-param name="regexp" select="'^.{0,250}$'"/>
        </xsl:call-template>
        
        <xsl:apply-templates select="cac:BillingReference/cac:InvoiceDocumentReference">
            <xsl:with-param name="tipoComprobante" select="$tipoComprobante"/>
        </xsl:apply-templates>
        
        <xsl:apply-templates select="cac:DespatchDocumentReference"/>
        
        <xsl:apply-templates select="cac:AdditionalDocumentReference"/>
        
        <!-- 
        ===========================================================================================================================================
        
        Documentos de referencia
        
        ===========================================================================================================================================
        -->
        
        <!-- 
        ===========================================================================================================================================
        
        Datos del detalle o Ítem de la nota de debito
        
        ===========================================================================================================================================
        -->
        
        <xsl:apply-templates select="cac:DebitNoteLine">
            <xsl:with-param name="root" select="."/>
        </xsl:apply-templates>
        
        <!-- 
        ===========================================================================================================================================
        
        Datos del detalle o Ítem de la nota de debito
        
        ===========================================================================================================================================
        -->
        
        <!-- 
        ===========================================================================================================================================
        
        Totales de la nota de debito
        
        ===========================================================================================================================================
        -->
        <!-- /DebitNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation El Tag UBL no debe repetirse en el /DebitNote
        ERROR 2427 -->
        
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2427'" />
            <xsl:with-param name="node" select="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation" />
            <xsl:with-param name="expresion" select="count(ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation) &gt; 1" />
        </xsl:call-template>
        
        <!-- 
        /DebitNote/cac:RequestedMonetaryTotal/cbc:ChargeTotalAmount
        El formato del Tag UBL es diferente de decimal positivo de 12 enteros y hasta 2 decimales
           ERROR   2064
         -->
         <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2064'"/>
            <xsl:with-param name="node" select="cac:RequestedMonetaryTotal/cbc:ChargeTotalAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:RequestedMonetaryTotal/cbc:PayableAmount
        El formato del Tag UBL es diferente de decimal positivo de 12 enteros y hasta 2 decimales   
        ERROR   2062 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2062'"/>
            <xsl:with-param name="node" select="cac:RequestedMonetaryTotal/cbc:PayableAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
        </xsl:call-template>
        
        <!-- sac:AdditionalMonetaryTotal -->
        <xsl:apply-templates select="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal"/>
        
        <!-- Tributos duplicados por cabecera -->
        <xsl:apply-templates select="cac:TaxTotal/cac:TaxSubtotal" mode="cabecera"/>
        
        <!-- Tributos de la cabecera-->
        <xsl:apply-templates select="cac:TaxTotal" mode="cabecera">
            <xsl:with-param name="root" select="."/>
        </xsl:apply-templates>
        
        
        <!-- 
        ===========================================================================================================================================
        
        Fin Totales de la nota de debito
        
        ===========================================================================================================================================
        -->
        
        <!-- Retornamos el comprobante al flujo necesario para lotes -->
        <xsl:copy-of select="."/>
        
    </xsl:template>
        
    <!-- 
    ===========================================================================================================================================
    *******************************************************************************************************************************************
                                                       TEMPLATES
    *******************************************************************************************************************************************
    ===========================================================================================================================================
    -->
    
    <!-- 
    ===========================================================================================================================================
    
    ============================================ Template cac:AccountingSupplierParty =========================================================
    
    ===========================================================================================================================================
    -->
    <xsl:template match="cac:AccountingSupplierParty">
    
        <!-- /DebitNote/cac:AccountingSupplierParty/cbc:AdditionalAccountID No existe el Tag UBL
        ERROR 1008 -->
        
        <!-- /DebitNote/cac:AccountingSupplierParty/cbc:AdditionalAccountID El Tag UBL es diferente a "6"
        ERROR 1007 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'1008'"/>
            <xsl:with-param name="errorCodeValidate" select="'1007'"/>
            <xsl:with-param name="node" select="cbc:AdditionalAccountID"/>
            <xsl:with-param name="regexp" select="'^(6)$'"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:AccountingSupplierParty/cbc:AdditionalAccountID Existe más de un Tag UBL en el XML
        ERROR 2362 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2362'" />
            <xsl:with-param name="node" select="cbc:AdditionalAccountID" />
            <xsl:with-param name="expresion" select="count(cbc:AdditionalAccountID)>1" />
        </xsl:call-template>
        
        <!-- /DebitNote/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName No existe el Tag UBL
        ERROR 1037 -->
        
        <!-- /DebitNote/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName El formato del Tag UBL es diferente a alfanumérico de hasta 1000 caracteres
        ERROR 1038 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'1037'"/>
            <xsl:with-param name="errorCodeValidate" select="'1038'"/>
            <xsl:with-param name="node" select="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>
            <!--<xsl:with-param name="regexp" select="'^(?!\s*$)[^\s].{2,999}$'"/>--><!-- de tres a 1000 caracteres que no inicie por espacio -->
            <!-- PAS20181U210300051 jas 090718 -->
			<xsl:with-param name="regexp" select="'^.{0,1000}$'"/> <!-- Hasta 1000 caracteres que pueden iniciar con espacio -->	
			</xsl:call-template>
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:AccountingSupplierParty ======================================================
    
    ===========================================================================================================================================
    -->
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:AccountingCustomerParty =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:AccountingCustomerParty">
        <xsl:param name="root" select = "'-'" />
        <xsl:param name="tipoComprobante" select = "'-'" />
        
        <!-- /DebitNote/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID No existe el Tag UBL
        ERROR 2014 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2014'"/>
            <xsl:with-param name="node" select="cbc:CustomerAssignedAccountID"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID Si "Tipo de documento de identidad del adquiriente" es RUC (6), el formato del Tag UBL es diferente a numérico de 11 dígitos
        ERROR 2017 -->
        <xsl:if test="cbc:AdditionalAccountID ='6'">
            <xsl:call-template name="regexpValidateElementIfExist">
             <xsl:with-param name="errorCodeValidate" select="'2017'"/>
             <xsl:with-param name="node" select="cbc:CustomerAssignedAccountID"/>
             <xsl:with-param name="regexp" select="'^[\d]{11}$'"/>
         </xsl:call-template>
        </xsl:if>
        
        
        <!-- /DebitNote/cac:AccountingCustomerParty/cbc:AdditionalAccountID No existe el Tag UBL
        ERROR 2015 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2015'"/>
            <xsl:with-param name="node" select="cbc:AdditionalAccountID"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:AccountingCustomerParty/cbc:AdditionalAccountID Si existe algún "Afectación al IGV por la línea" igual a 40 (Exportación) o la Serie del comprobante empieza con "B", el Tag UBL es diferente al listado o guión "-"
        ERROR 2016 -->
<!--         <xsl:choose>
            <xsl:when test="$root/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode[text() ='40'] or $tipoComprobante ='03'  or $tipoComprobante ='14'">
                <xsl:if test="cbc:AdditionalAccountID or cbc:AdditionalAccountID != '-'">
                    <xsl:call-template name="findElementInCatalog">
                        <xsl:with-param name="catalogo" select="'06'"/>
                        <xsl:with-param name="idCatalogo" select="cbc:AdditionalAccountID"/>
                        <xsl:with-param name="errorCodeValidate" select="'2016'"/>
                    </xsl:call-template>
                </xsl:if>
                
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="regexpValidateElementIfExist">
                    <xsl:with-param name="errorCodeValidate" select="'2016'"/>
                    <xsl:with-param name="node" select="cbc:AdditionalAccountID"/>
                    <xsl:with-param name="regexp" select="'^6$'"/>
                </xsl:call-template>
            </xsl:otherwise>
        </xsl:choose> -->
        
		
        <!-- Ajuste Pase81 jas300418 /DebitNote/cac:AccountingCustomerParty/cbc:AdditionalAccountID el Tag es diferente al catalogo 6 - ERROR 2016 -->
                <xsl:call-template name="regexpValidateElementIfExist">
                    <xsl:with-param name="errorCodeValidate" select="'2016'"/>
                    <xsl:with-param name="node" select="cbc:AdditionalAccountID"/>
                    <xsl:with-param name="regexp" select="'^[01467ABCDE\-]$'"/>
                </xsl:call-template>
                	
        
        <!-- /DebitNote/cac:AccountingCustomerParty/cbc:AdditionalAccountID Existe más de un Tag UBL en el XML
        ERROR 2363 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2363'" />
            <xsl:with-param name="node" select="cbc:AdditionalAccountID" />
            <xsl:with-param name="expresion" select="count(cbc:AdditionalAccountID)>1" />
        </xsl:call-template>
        
        <!-- /DebitNote/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName No existe el Tag UBL
        ERROR 2021 -->
        
        <!-- /DebitNote/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName El formato del Tag UBL es diferente a alfanumérico de 3 hasta 1000 caracteres
        ERROR 2022 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2021'"/>
            <xsl:with-param name="errorCodeValidate" select="'2022'"/>
            <xsl:with-param name="node" select="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>            
            <!--<xsl:with-param name="regexp" select="'^(?!\s*$)[^\s].{2,999}$'"/>--><!-- de tres a 1000 caracteres que no inicie por espacio -->
            <!-- PAS20181U210300051 jas 090718 -->			
            <xsl:with-param name="regexp" select="'^.{0,1000}$'"/> <!-- de tres a 1000 caracteres que puede iniciar con espacios -->				
        </xsl:call-template>
        
        <!--  Si "Tipo de operación" es 13 y el "Tipo de documento de identidad del adquiriente o usuario" es 1, el formato del Tag UBL es diferente de numérico de 8 dígitos 
        ERROR 2801 -->
        <xsl:if test="cbc:AdditionalAccountID ='1'">
            <xsl:call-template name="regexpValidateElementIfExist">
                <xsl:with-param name="errorCodeValidate" select="'2801'"/>
                <xsl:with-param name="node" select="cbc:CustomerAssignedAccountID"/>
                <xsl:with-param name="regexp" select="'^[\d]{8}$'"/>
            </xsl:call-template>
        </xsl:if>
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:AccountingCustomerParty =========================================== 
    
    ===========================================================================================================================================
    -->
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:BillingReference/cac:InvoiceDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:BillingReference/cac:InvoiceDocumentReference">
        <xsl:param name="tipoComprobante" select = "'-'" />
 
 
       <!--  (cbc:DocumentTypeCode and not (cbc:ReferenceID)) or (not(cbc:DocumentTypeCode) and cbc:ReferenceID)  -->
        
        
 
        <xsl:choose>
            <!-- si es una nota de debito de factura -->
            <xsl:when test="$tipoComprobante ='01'">
            
            
                <xsl:choose>
                
                    <xsl:when test="cbc:DocumentTypeCode='01'">
                        <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID "Si la nota de debito modifica una Factura, la serie debe iniciar con F. 
                        Si la ND modifica a una boleta de venta (tipo de comprobante =01), y el formato del Tag UBL es diferente a:^(([F][A-Z0-9]{3}-[0-9]{1,8})|((E001)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8}))$"
                        ERROR 2205 -->
                        <xsl:call-template name="existAndRegexpValidateElement">
                            <xsl:with-param name="errorCodeNotExist" select="'2205'"/>
                            <xsl:with-param name="errorCodeValidate" select="'2205'"/>
                            <xsl:with-param name="node" select="cbc:ID"/>
                            <xsl:with-param name="regexp" select="'^(([F][A-Z0-9]{3}-[0-9]{1,8})|((E001)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8}))$'"/>
                        </xsl:call-template>
                    
                    </xsl:when>
                    
                    <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID "Si ""Tipo del documento del documento que modifica"" es ""12"", el formato del Tag UBL es diferente a: ^([a-zA-Z0-9-]{1,20}-[0-9]{1,10})$"
                     ERROR 2205 -->
                     <xsl:when test="cbc:DocumentTypeCode='12'">
                        <xsl:call-template name="existAndRegexpValidateElement">
                             <xsl:with-param name="errorCodeNotExist" select="'2205'"/>
                             <xsl:with-param name="errorCodeValidate" select="'2205'"/>
                             <xsl:with-param name="node" select="cbc:ID"/>
                             <xsl:with-param name="regexp" select="'^([a-zA-Z0-9-]{1,20}-[0-9]{1,10})$'"/>
                         </xsl:call-template>
                     </xsl:when>
                     
                     <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID Si "Tipo del documento del documento que modifica" es "56", el valor del Tag UBL es alfanumérico
                     ERROR 2205 -->
                     <xsl:when test="cbc:DocumentTypeCode='56'">
                        <xsl:call-template name="existAndRegexpValidateElement">
                             <xsl:with-param name="errorCodeNotExist" select="'2205'"/>
                             <xsl:with-param name="errorCodeValidate" select="'2205'"/>
                             <xsl:with-param name="node" select="cbc:ID"/>
                             <xsl:with-param name="regexp" select="'^[\w\d\- ]+$'"/>
                         </xsl:call-template>
                     </xsl:when>
                     
                 </xsl:choose>
        
                
                
                <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:DocumentTypeCode Si la Serie del comprobante empieza con "F", el Tag UBL es diferente de "01", "12", "56"
                ERROR 2204 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2204'" />
                    <xsl:with-param name="node" select="cbc:DocumentTypeCode" />
                    <xsl:with-param name="expresion" select="not(cbc:DocumentTypeCode) or cbc:DocumentTypeCode[text() !='01' and text() !='12' and text() !='56']" />
                </xsl:call-template>
                
                
                
            </xsl:when>
            
            <!-- si es una nota de debito de Boleta -->
            <xsl:when test="$tipoComprobante ='03'">
                <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID "Si la nota de debito modifica una Boleta de venta, la serie debe iniciar con B. 
                Si la ND modifica a una boleta de venta (tipo de comprobante =03), y el formato del Tag UBL es diferente a:^(([B][A-Z0-9]{3}-[0-9]{1,8})|((EB01)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8}))$"
                ERROR 2205 -->
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2205'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2205'"/>
                    <xsl:with-param name="node" select="cbc:ID"/>
                    <xsl:with-param name="regexp" select="'^(([B][A-Z0-9]{3}-[0-9]{1,8})|((EB01)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8}))$'"/>
                </xsl:call-template>
                
                <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:DocumentTypeCode Si la Serie del comprobante empieza con "B", el Tag UBL es diferente de "03"
                ERROR 2400 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2400'" />
                    <xsl:with-param name="node" select="cbc:DocumentTypeCode" />
                    <xsl:with-param name="expresion" select="not(cbc:DocumentTypeCode) or  cbc:DocumentTypeCode[text() != '03']" />
                </xsl:call-template>
                
            </xsl:when>
        
        	<!-- si es una nota de debito de Boleta -->
            <xsl:when test="$tipoComprobante ='14'">
                
                    <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID "Si la nota de debito modifica una servicios publicos, la serie debe iniciar con S. 
                    ERROR 2205 -->
                    <xsl:call-template name="existAndRegexpValidateElement">
                        <xsl:with-param name="errorCodeNotExist" select="'2205'"/>
                        <xsl:with-param name="errorCodeValidate" select="'2205'"/>
                        <xsl:with-param name="node" select="cbc:ID"/>
                        <xsl:with-param name="regexp" select="'^(([S][A-Z0-9]{3}-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8})|(--[0-9]{1,8}))$'"/>
                    </xsl:call-template>
                
                
                <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:DocumentTypeCode Si la Serie del comprobante empieza con "B", el Tag UBL es diferente de "03"
                ERROR 2400 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2930'" />
                    <xsl:with-param name="node" select="cbc:DocumentTypeCode" />
                    <xsl:with-param name="expresion" select="not(cbc:DocumentTypeCode) or  cbc:DocumentTypeCode[text() != '14']" />
                </xsl:call-template>
                
            </xsl:when>
        </xsl:choose>
        
        
        
        <!-- /DebitNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID El valor del Tag UBL no debe repetirse en el /DebitNote
        ERROR 2365 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2365'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-Billingreference', concat(cbc:DocumentTypeCode, cbc:ID))) > 1" />
        </xsl:call-template>
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:BillingReference/cac:InvoiceDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:DespatchDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:DespatchDocumentReference">
    
        <!-- /DebitNote/cac:DespatchDocumentReference/cbc:ID "Si el Tag UBL existe, el formato del Tag UBL es diferente a: ^(([T][0-9]{3}-[0-9]{1,8})|([0-9]{4}-[0-9]{1,8})|([E][G][0-9]{2}-[0-9]{1,8})|([G][0-9]{3}-[0-9]{1,8}))$ 
        OBSERV 4006 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'4006'"/>
            <xsl:with-param name="errorCodeValidate" select="'4006'"/>
            <xsl:with-param name="node" select="cbc:ID"/>
            <xsl:with-param name="regexp" select="'^(([T][0-9]{3}-[0-9]{1,8})|([0-9]{4}-[0-9]{1,8})|([E][G][0-9]{2}-[0-9]{1,8})|([G][0-9]{3}-[0-9]{1,8}))$'"/>
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DespatchDocumentReference/cbc:ID El "Tipo de la guía de remisión relacionada" concatenada con el valor del Tag UBL no debe repetirse en el /DebitNote
        ERROR 2364 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2364'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-document-despatch-reference', concat(cbc:DocumentTypeCode,' ',cbc:ID))) > 1" />
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DespatchDocumentReference/cbc:DocumentTypeCode Si existe el Tag UBL, el formato del Tag UBL es diferente de "09" o "31" 
        OBSERV 4005 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'4005'"/>
            <xsl:with-param name="errorCodeValidate" select="'4005'"/>
            <xsl:with-param name="node" select="cbc:DocumentTypeCode"/>
            <xsl:with-param name="regexp" select="'^(31)|(09)$'"/>
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:DespatchDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:AdditionalDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:AdditionalDocumentReference">
        
        <!-- /DebitNote/cac:AdditionalDocumentReference/cbc:ID El formato del Tag UBL es diferente a alfanumérico de entre 6 y 30 caracteres (letras, números y guión) 
        OBSERV 4010 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'4010'"/>
            <xsl:with-param name="errorCodeValidate" select="'4010'"/>
            <xsl:with-param name="node" select="cbc:ID"/>
            <xsl:with-param name="regexp" select="'^(?!\s*$)[^\s]{6,30}$'"/>
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:AdditionalDocumentReference/cbc:ID El "Tipo de otro documento relacionado" concatenado con el valor del Tag UBL, no debe repetirse en el /DebitNote
        ERROR 2426 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2426'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-document-additional-reference', concat(cbc:DocumentTypeCode,' ',cbc:ID))) > 1" />
        </xsl:call-template>
        
        <!-- /DebitNote/cac:AdditionalDocumentReference/cbc:DocumentTypeCode El formato del Tag UBL es diferente de "04" o "05" o "99" o "01" 
        OBSERV 4009 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'4009'"/>
            <xsl:with-param name="errorCodeValidate" select="'4009'"/>
            <xsl:with-param name="node" select="cbc:DocumentTypeCode"/>
            <xsl:with-param name="regexp" select="'^(0[145]|99)$'"/>
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:AdditionalDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:DebitNoteLine =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:DebitNoteLine">
    
        <xsl:param name="root"/>
        
        <xsl:variable name="nroLinea" select="cbc:ID"/>
        
        <xsl:variable name="tipoOperacion" select="$root/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:SUNATTransaction/cbc:ID"/>
        
        <xsl:variable name="codigoPrecio" select="cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode"/>
        
        <!-- /DebitNote/cac:DebitNoteLine/cbc:ID El formato del Tag UBL es diferente de numérico de 3 dígitos
        ERROR 2187 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2187'"/>
            <xsl:with-param name="errorCodeValidate" select="'2187'"/>
            <xsl:with-param name="node" select="cbc:ID"/>
            <xsl:with-param name="regexp" select="'^(?!0*$)\d{1,3}$'"/> <!-- de tres numeros como maximo, no cero -->
            <xsl:with-param name="descripcion" select="concat('Error en la linea:', position(), '. ')"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DebitNoteLine/cbc:ID El valor del Tag UBL no debe repetirse en el /DebitNote
        ERROR 2752 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2752'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-invoiceLine-id', number(cbc:ID))) > 1" />
            <xsl:with-param name="descripcion" select="concat('Error en la linea:', position(), '. ')"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DebitNoteLine/cbc:DebitedQuantity/@unitCode Si el Tag UBL existe, no existe el atributo del Tag UBL
        ERROR 2188 -->
        <xsl:if test="cbc:DebitedQuantity">
            <xsl:call-template name="existElement">
                <xsl:with-param name="errorCodeNotExist" select="'2188'"/>
                <xsl:with-param name="node" select="cbc:DebitedQuantity/@unitCode"/>
                <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
            </xsl:call-template>
        </xsl:if>
        
        <!-- /DebitNote/cac:DebitNoteLine/cbc:cbc:DebitedQuantity Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 10 decimales
        ERROR 2189 -->
        <!-- Cantidad de unidades por item -->
<!--         <xsl:call-template name="validateValueTenDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2189'"/>
            <xsl:with-param name="node" select="cbc:DebitedQuantity"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template> -->
				
		
		<!-- PAS20181U210300051 jas 090718 -->		
        <!-- /DebitNote/cac:DebitNoteLine/cbc:cbc:DebitedQuantity Si el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 10 decimales ERROR 2189, incluye ceros al comienzo -->		
		<xsl:call-template name="regexpValidateElementIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2189'"/>
            <xsl:with-param name="node" select="cbc:DebitedQuantity"/>
			<xsl:with-param name="regexp" select="'^[0-9\s]{1,12}(\.[0-9\s]{1,10})?'"/>
			<xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>	
		
        
        <!-- /DebitNote/cac:DebitNoteLine/cac:Price/cbc:PriceAmount Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 10 decimales
        ERROR 2369 -->
        <xsl:call-template name="validateValueTenDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2369'"/>
            <xsl:with-param name="node" select="cac:Price/cbc:PriceAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DebitNoteLine/cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 10 decimales
        ERROR 2367 -->
        <xsl:call-template name="validateValueTenDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2367'"/>
            <xsl:with-param name="node" select="cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        
        
        <!-- /DebitNote/cac:DebitNoteLine/cbc:LineExtensionAmount El formato del Tag UBL es diferente de decimal (positivo o negativo) de 12 enteros y hasta 2 decimales
        ERROR 2370 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2370'"/>
            <xsl:with-param name="node" select="cbc:LineExtensionAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <xsl:for-each select="cac:PricingReference/cac:AlternativeConditionPrice">
            <!-- /DebitNote/cac:DebitNoteLine/cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode Si el Tag UBL existe, el valor del Tag UBL es diferente al Catálogo 16
            ERROR 2410 -->
            <xsl:call-template name="findElementInCatalog">
                <xsl:with-param name="catalogo" select="'16'"/>
                <xsl:with-param name="idCatalogo" select="cbc:PriceTypeCode"/>
                <xsl:with-param name="errorCodeValidate" select="'2410'"/>
                <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
            </xsl:call-template>
            
        </xsl:for-each>
        
        <!-- /DebitNote/cac:DebitNoteLine/cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode El valor del Tag UBL no debe repertirse en el /DebitNote/cac:DebitNoteLine/cac:PricingReference/cac:AlternativeConditionPrice
        ERROR 2409 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2409'" />
            <xsl:with-param name="node" select="cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode" />
            <xsl:with-param name="expresion" select="(count(cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode[text()='01'])>1 or count(cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode[text()='02'])>1)" />
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- Tributos por linea de detalle -->
        <xsl:apply-templates select="cac:TaxTotal" mode="linea">
            <xsl:with-param name="nroLinea" select="$nroLinea"/>
            <xsl:with-param name="root" select="$root"/>
        </xsl:apply-templates>
        
        <!-- Tributos duplicados por linea -->
        <xsl:apply-templates select="cac:TaxTotal/cac:TaxSubtotal" mode="linea">
           <xsl:with-param name="nroLinea" select="$nroLinea"/>
        </xsl:apply-templates>
          
    </xsl:template>
    
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:DebitNoteLine =========================================== 
    
    ===========================================================================================================================================
    -->
    
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:TaxTotal/cac:TaxSubtotal =========================================== 
    
    ===========================================================================================================================================
    -->        
    <xsl:template match="cac:TaxTotal/cac:TaxSubtotal" mode="linea">
        <xsl:param name="nroLinea"/>
        
        <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID El valor del Tag UBL no debe repetirse en el /DebitNote/cac:DebitNoteLine
        ERROR 2355 -->
        
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2355'" />
            <xsl:with-param name="node" select="cac:TaxCategory/cac:TaxScheme/cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-tributos-in-line', concat(cac:TaxCategory/cac:TaxScheme/cbc:ID,'-', $nroLinea))) > 1" />
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
      
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:TaxTotal/cac:TaxSubtotal =========================================== 
    
    ===========================================================================================================================================
    -->    
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:TaxTotal =========================================== 
    
    ===========================================================================================================================================
    -->
    <xsl:template match="cac:TaxTotal" mode="linea">
        <xsl:param name="nroLinea"/>
        <xsl:param name="root"/>
        
        <xsl:variable name="tipoOperacion" select="$root/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:SUNATTransaction/cbc:ID"/>
        
        
        <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cbc:TaxAmount Si el Tag UBL existe, el Tag UBL es diferente al Tag anterior
        ERROR 2372 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2372'" />
            <xsl:with-param name="node" select="cbc:TaxAmount" />
            <xsl:with-param name="expresion" select="number(cac:TaxSubtotal/cbc:TaxAmount) != number(cbc:TaxAmount)" />
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        
        <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name No existe el Tag UBL
        ERROR 2195 -->
        
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2195'"/>
            <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cbc:TaxAmount Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 2 decimales
        ERROR 2033 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2033'"/>
            <xsl:with-param name="node" select="cbc:TaxAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID Si el Tag UBL existe, el valor del Tag UBL es diferente al listado
        ERROR 2194 -->
        <xsl:call-template name="findElementInCatalog">
            <xsl:with-param name="catalogo" select="'05'"/>
            <xsl:with-param name="idCatalogo" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
            <xsl:with-param name="errorCodeValidate" select="'2194'"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <xsl:choose>
            <xsl:when test="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID = '1000'">
        
                <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode Si "Código de tributo por línea" es 1000 (IGV), no existe el Tag UBL
                ERROR 2371 -->
                <xsl:call-template name="existElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2371'"/>
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode"/>
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode Si "Código de tributo por línea" es 1000 (IGV), el valor del Tag UBL es diferente al Catálogo 7
                ERROR 2197 -->
                <xsl:call-template name="findElementInCatalog">
                    <xsl:with-param name="catalogo" select="'07'"/>
                    <xsl:with-param name="idCatalogo" select="cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode"/>
                    <xsl:with-param name="errorCodeValidate" select="'2197'"/>
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name Si "Código de tributo por línea" es 1000 (IGV), el valor del Tag UBL es diferente de "IGV"
                ERROR 2377 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2377'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:Name != 'IGV'" />
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea, '. cbc:Name debe de ser IGV')"/>
                </xsl:call-template>
                
                <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode Si "Código de tributo por línea" es 1000, el valor del Tag UBL es diferente al código internacional del listado para el "Código de tributo por línea" 
                ERROR 2377 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2377'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:TaxTypeCode != 'VAT'" />
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea, '. cbc:TaxTypeCode debe ser VAT')"/>
                </xsl:call-template>
        
            </xsl:when>
        
            <xsl:when test="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID = '2000'">
            
                <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TierRange Si "Código de tributo por línea" es 2000 (ISC), no existe el Tag UBL
                ERROR 2373 -->
                <xsl:call-template name="existElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2373'"/>
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cbc:TierRange"/>
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                
                <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TierRange Si "Código de tributo por línea" es 2000 (ISC), el valor del Tag UBL es diferente al listado
                ERROR 2199 -->
                <xsl:call-template name="findElementInCatalog">
                    <xsl:with-param name="catalogo" select="'08'"/>
                    <xsl:with-param name="idCatalogo" select="cac:TaxSubtotal/cac:TaxCategory/cbc:TierRange"/>
                    <xsl:with-param name="errorCodeValidate" select="'2199'"/>
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name Si "Código de tributo por línea" es 2000 (ISC), el valor del Tag UBL es diferente de "ISC"
                ERROR 2378 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2378'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:Name != 'ISC'" />
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                <!-- /DebitNote/cac:DebitNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode Si "Código de tributo por línea" es 2000, el valor del Tag UBL es diferente al código internacional del listado para el "Código de tributo por línea" 
                ERROR 2378 -->                
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2378'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:TaxTypeCode != 'EXC'" />
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
            </xsl:when>
           
        </xsl:choose>
       
    </xsl:template>
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:TaxTotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
    
    <!-- 
    ===========================================================================================================================================
    
    ========== Template ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal =========
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal">
    
        <!-- /DebitNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal/cbc:ID El valor del Tag UBL no debe repetirse en el /DebitNote 
        ERROR 2046 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2406'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-AdditionalMonetaryTotal', cbc:ID)) > 1" />
        </xsl:call-template>
        
        <!-- /DebitNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal/cbc:ID El valor del Tag UBL es diferente al listado
        ERROR 2340 -->
        <xsl:call-template name="findElementInCatalog">
            <xsl:with-param name="catalogo" select="'14'"/>
            <xsl:with-param name="idCatalogo" select="cbc:ID"/>
            <xsl:with-param name="errorCodeValidate" select="'2340'"/>
        </xsl:call-template>
        
        <!-- /DebitNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal/cbc:PayableAmount El formato del Tag UBL es diferente de decimal de 12 enteros y hasta 2 decimales
        ERROR 2339 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2339'"/>
            <xsl:with-param name="node" select="cbc:PayableAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
        </xsl:call-template>        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    ======== Fin Template ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal =========
    
    ===========================================================================================================================================
    -->
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:TaxTotal/cac:TaxSubtotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:TaxTotal/cac:TaxSubtotal" mode="cabecera">
        
        <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID El valor del Tag UBL no debe repetirse en el /DebitNote
        ERROR 2352 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2352'" />
            <xsl:with-param name="node" select="cac:TaxCategory/cac:TaxScheme/cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-tributos-in-root', cac:TaxCategory/cac:TaxScheme/cbc:ID)) > 1" />
        </xsl:call-template>     
        
      
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:TaxTotal/cac:TaxSubtotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
    
<!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:TaxTotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:TaxTotal" mode="cabecera">
        
        <xsl:param name="root"/>
        
        <xsl:variable name="tipoOperacion" select="$root/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:SUNATTransaction/cbc:ID"/>
        
        
        <!-- /DebitNote/cac:TaxTotal/cbc:TaxAmount El formato del Tag UBL es diferente de decimal de 12 enteros y hasta 2 decimales
        ERROR 2202 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2202'"/>
            <xsl:with-param name="node" select="cbc:TaxAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cbc:TaxAmount El Tag UBL es diferente al Tag anterior
        ERROR 2061 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2061'" />
            <xsl:with-param name="node" select="cbc:TaxAmount" />
            <xsl:with-param name="expresion" select="number(cac:TaxSubtotal/cbc:TaxAmount) != number(cbc:TaxAmount)" />
        </xsl:call-template>
        
        <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID No existe el Tag UBL
        ERROR 2184 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2184'"/>
            <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
        </xsl:call-template>
        
        <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID El valor del Tag UBL es diferente al listado
        ERROR 2183 -->
        <xsl:call-template name="findElementInCatalog">
            <xsl:with-param name="catalogo" select="'05'"/>
            <xsl:with-param name="idCatalogo" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
            <xsl:with-param name="errorCodeValidate" select="'2183'"/>
        </xsl:call-template>
        
        
        <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name No existe el Tag UBL
        ERROR 2186 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2186'"/>
            <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name"/>
        </xsl:call-template>
        
        
        <xsl:choose>
            <xsl:when test="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID = '1000'">
                <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name Si "Código de tributo" es 1000 (IGV), el valor del Tag UBL es diferente de "IGV"
                ERROR 2057 -->
                
                <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode Si "Código de tributo" es 1000 (IGV), el valor del Tag UBL es diferente al código internacional del listado para el "Código de tributo"
                ERROR 2057 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2057'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:Name[text() != 'IGV']
                    or
                        not(cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:TaxTypeCode)
                        or
                        cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:TaxTypeCode[text() != 'VAT']" />
                </xsl:call-template>
            </xsl:when>
            
            <xsl:when test="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID = '2000'">
                <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name Si "Código de tributo" es 2000 (ISC), el valor del Tag UBL es diferente de "ISC"
                ERROR 2058 -->
                
                <!-- /DebitNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode Si "Código de tributo" es 2000 (ISC), el valor del Tag UBL es diferente de "ISC"
                ERROR 2058 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2058'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:Name[text() != 'ISC']
                    or
                        not(cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:TaxTypeCode)
                        or
                        cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:TaxTypeCode[text() != 'EXC']" />
                </xsl:call-template>
            </xsl:when>
        
        </xsl:choose>
      
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:TaxTotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
   
</xsl:stylesheet>