<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" 
    xmlns:regexp="http://exslt.org/regular-expressions"
    xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2" 
    xmlns:ds="http://www.w3.org/2000/09/xmldsig#" 
    xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2" 
    xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1"
    xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2" 
    xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2" 
    xmlns:dp="http://www.datapower.com/extensions" 
    extension-element-prefixes="dp" exclude-result-prefixes="dp" version="1.0">
    <!-- xsl:include href="../../../commons/error/validate_utils.xsl" dp:ignore-multiple="yes" / -->
    <xsl:include href="local:///commons/error/validate_utils.xsl" dp:ignore-multiple="yes" />
    
    
    <!-- key Documentos Relacionados Duplicados -->
    <xsl:key name="by-document-despatch-reference" match="*[local-name()='CreditNote']/cac:DespatchDocumentReference" use="concat(cbc:DocumentTypeCode,' ', cbc:ID)"/>
    
    <xsl:key name="by-document-additional-reference" match="*[local-name()='CreditNote']/cac:AdditionalDocumentReference" use="concat(cbc:DocumentTypeCode,' ', cbc:ID)"/>
    
    <!-- key Numero de lineas duplicados fin -->
    <xsl:key name="by-invoiceLine-id" match="*[local-name()='CreditNote']/cac:CreditNoteLine" use="number(cbc:ID)"/>
    
    <!-- key tributos duplicados por linea -->
    <xsl:key name="by-tributos-in-line" match="cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal" use="concat(cac:TaxCategory/cac:TaxScheme/cbc:ID,'-', ../../cbc:ID)"/>
    
    <!-- key tributos duplicados por cabecera -->
    <xsl:key name="by-tributos-in-root" match="*[local-name()='CreditNote']/cac:TaxTotal/cac:TaxSubtotal" use="cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
    
    <!-- key AdditionalMonetaryTotal duplicados -->
    <xsl:key name="by-AdditionalMonetaryTotal" match="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal" use="cbc:ID"/>
    
    <xsl:key name="by-Billingreference" match="cac:CreditNoteLine/cac:BillingReference/cac:InvoiceDocumentReference" use="concat(cbc:DocumentTypeCode, cbc:ID)"/>
    
    
	<xsl:template match="/*">
    
        <!-- 
        ===========================================================================================================================================
        Variables  
        ===========================================================================================================================================
        -->
        <!-- Validando que el nombre del archivo coincida con la informacion enviada en el XML -->
        
        <xsl:variable name="numeroRuc" select="substring(dp:variable('var://context/cpe/nombreArchivoEnviado'), 1, 11)"/>
        
        <xsl:variable name="numeroSerie" select="substring(dp:variable('var://context/cpe/nombreArchivoEnviado'), 16, 4)"/>
        
        <xsl:variable name="tipoComprobante">
            <xsl:choose>
                <xsl:when test="substring($numeroSerie, 1, 1) = 'F' ">
                    <xsl:value-of select="'01'"/>
                </xsl:when>
                <xsl:when test="substring($numeroSerie, 1, 1) = 'S' ">
                    <xsl:value-of select="'14'"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="'03'"/>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>
        
        <xsl:variable name="numeroComprobante" select="substring(dp:variable('var://context/cpe/nombreArchivoEnviado'), 21, string-length(dp:variable('var://context/cpe/nombreArchivoEnviado')) - 24)"/>
        
        <xsl:variable name="monedaComprobante" select="cbc:DocumentCurrencyCode/text()"/>
        
        <xsl:variable name="tipoOperacion" select="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:SUNATTransaction/cbc:ID/text()"/>
        
        <!-- 
        ===========================================================================================================================================
        Variables  
        ===========================================================================================================================================
        -->
        
        <!-- Numero de RUC del nombre del archivo no coincide con el consignado en el contenido del archivo XML -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'1034'" />
            <xsl:with-param name="node" select="cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID" />
            <xsl:with-param name="expresion" select="$numeroRuc != cac:AccountingSupplierParty/cbc:CustomerAssignedAccountID" />
        </xsl:call-template>
        
        <!-- Numero de Serie del nombre del archivo no coincide con el consignado en el contenido del archivo XML -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'1035'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="$numeroSerie != substring(cbc:ID, 1, 4)" />
        </xsl:call-template>
        
        <!-- Numero de documento en el nombre del archivo no coincide con el consignado en el contenido del XML -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'1036'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="$numeroComprobante != substring(cbc:ID, 6)" />
        </xsl:call-template>
    
        <!-- 
        ===========================================================================================================================================
        
        Datos de la Nota de credito  
        
        ===========================================================================================================================================
        -->
        
        
        <!-- /CreditNote/cbc:UBLVersionID No existe el Tag UBL
        ERROR 2075 -->
        
        <!-- /CreditNote/cbc:UBLVersionID El valor del Tag UBL es diferente de "2.0"
        ERROR 2074 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2075'"/>
            <xsl:with-param name="errorCodeValidate" select="'2074'"/>
            <xsl:with-param name="node" select="cbc:UBLVersionID"/>
            <xsl:with-param name="regexp" select="'^(2.0)$'"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cbc:CustomizationID No existe el Tag UBL
        ERROR 2073 -->
        
        <!-- /CreditNote/cbc:CustomizationID El valor del Tag UBL es diferente de "1.0"
        ERROR 2072 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2073'"/>
            <xsl:with-param name="errorCodeValidate" select="'2072'"/>
            <xsl:with-param name="node" select="cbc:CustomizationID"/>
            <xsl:with-param name="regexp" select="'^(1.0)$'"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:DiscrepancyResponse Existe más de un Tag UBL en el /CreditNote
        ERROR 2415 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2415'" />
            <xsl:with-param name="node" select="cac:DiscrepancyResponse" />
            <xsl:with-param name="expresion" select="count(cac:DiscrepancyResponse)>1" />
        </xsl:call-template>
        
        <!-- /CreditNote/cac:DiscrepancyResponse/cbc:ReferenceID No existe el Tag UBL
        ERROR 2414 -->
        
        <!-- /CreditNote/cac:DiscrepancyResponse/cbc:ReferenceID El valor del Tag UBL es vacío
        ERROR 2125 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2414'"/>
            <xsl:with-param name="errorCodeValidate" select="'2125'"/>
            <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
            <xsl:with-param name="regexp" select="'^((?!\s*$)[^\s].*)$'"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:DiscrepancyResponse/cbc:ResponseCode No existe el Tag UBL o es vacío
        ERROR 2128 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2128'"/>
            <xsl:with-param name="errorCodeValidate" select="'2128'"/>
            <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ResponseCode"/>
            <xsl:with-param name="regexp" select="'^((?!\s*$)[^\s].*)$'"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:DiscrepancyResponse/cbc:ResponseCode El Tag UBL no existe en el listado
        ERROR 2172 -->
        <xsl:call-template name="findElementInCatalog">
            <xsl:with-param name="catalogo" select="'09'"/>
            <xsl:with-param name="idCatalogo" select="cac:DiscrepancyResponse/cbc:ResponseCode"/>
            <xsl:with-param name="errorCodeValidate" select="'2172'"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:DiscrepancyResponse/cbc:Description No existe el Tag UBL
        ERROR 2136 -->
        
        <!-- /CreditNote/cac:DiscrepancyResponse/cbc:Description El formato del Tag UBL es diferente a alfanumérico de 1 hasta 250 caracteres
        ERROR 2135 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2136'"/>
            <xsl:with-param name="errorCodeValidate" select="'2135'"/>
            <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:Description"/>
			<!-- PAS20181U210300051 jas 170718 incluye espacios en blanco al comienzo y {.}  -->
            <!--<xsl:with-param name="regexp" select="'^(?!\s*$)[^\s].{1,249}$'"/>-->	
			<xsl:with-param name="regexp" select="'^.{0,250}$'"/>				
			</xsl:call-template>	
		
        
        <!-- /CreditNote/cbc:DocumentCurrencyCode No existe el Tag UBL
        ERROR 2070 -->
        
        <!-- /CreditNote/cbc:DocumentCurrencyCode El formato del Tag UBL es diferente a alfabético de 3 caracteres
        ERROR 2069 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2070'"/>
            <xsl:with-param name="errorCodeValidate" select="'2069'"/>
            <xsl:with-param name="node" select="cbc:DocumentCurrencyCode"/>
            <xsl:with-param name="regexp" select="'^([\w\d]{3})$'"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cbc:DocumentCurrencyCode La moneda de los totales de línea y totales de comprobantes es diferente al Tag UBL
        ERROR 2071 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2071'" />
            <xsl:with-param name="node" select="descendant::*[@currencyID != $monedaComprobante and not(ancestor-or-self::sac:AdditionalMonetaryTotal[cbc:ID='2001' or cbc:ID='2003'])]/@currencyID" />
            <xsl:with-param name="expresion" select="descendant::*[@currencyID != $monedaComprobante and not(ancestor-or-self::sac:AdditionalMonetaryTotal[cbc:ID='2001' or cbc:ID='2003'])]" />
        </xsl:call-template>
        
        <xsl:choose>
            <!-- /CreditNote/cac:DiscrepancyResponse/cbc:ReferenceID "Si ""Código de tipo de nota de crédito"" es ""10"" (Otros), el formato del Tag UBL es diferente a: ^([F][A-Z0-9]{3}-[0-9]{1,8}|(E001)-[0-9]{1,8}|[B][A-Z0-9]{3}-[0-9]{1,8}|(EB01)-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8}|[0-9]{1,8})$" 
            OBSERV 2634 -->
            <xsl:when test="cac:DiscrepancyResponse/cbc:ResponseCode = '10'">
                
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2414'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2634'"/>
                    <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
                    <xsl:with-param name="regexp" select="'^([F][A-Z0-9]{3}-[0-9]{1,8}|(E001)-[0-9]{1,8}|[B][A-Z0-9]{3}-[0-9]{1,8}|(EB01)-[0-9]{1,8}|[S][A-Z0-9]{3}-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8}|--[0-9]{1,8})$'"/>
                    <xsl:with-param name="isError" select="false()"/>
                </xsl:call-template>
                
            </xsl:when>
            
            <!-- /CreditNote/cac:DiscrepancyResponse/cbc:ReferenceID "Si ""Código de tipo de nota de crédito"" es diferente a 10, el formato del Tag UBL es diferente a: Para notas de credito de Factura ^([F][A-Z0-9]{3}-[0-9]{1,8}|(E001)-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8}|[0-9]{1,8})$ 
            ERROR 2125 -->
            <xsl:when test="$tipoComprobante = '01' and cac:DiscrepancyResponse/cbc:ResponseCode != '10'">
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2414'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2125'"/>
                    <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
                    <xsl:with-param name="regexp" select="'^([F][A-Z0-9]{3}-[0-9]{1,8}|(E001)-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8}|--[0-9]{1,8})$'"/>
                </xsl:call-template>                
            </xsl:when>
            
            <!-- /CreditNote/cac:DiscrepancyResponse/cbc:ReferenceID "Si ""Código de tipo de nota de crédito"" es diferente a 10, el formato del Tag UBL es diferente a: Para notas de credito de Boleta ^([B][A-Z0-9]{3}-[0-9]{1,8}|(EB01)-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8}|[0-9]{1,8})$"
            ERROR 2125 -->
            <xsl:when test="$tipoComprobante = '03' and cac:DiscrepancyResponse/cbc:ResponseCode != '10'">
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2414'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2125'"/>
                    <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
                    <xsl:with-param name="regexp" select="'^([B][A-Z0-9]{3}-[0-9]{1,8}|(EB01)-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8}|--[0-9]{1,8})$'"/>
                </xsl:call-template>                
            </xsl:when>
            <!-- /CreditNote/cac:DiscrepancyResponse/cbc:ReferenceID "Si ""Código de tipo de nota de crédito"" es diferente a 10, el formato del Tag UBL es diferente a: Para notas de servicios publicos ^([S][A-Z0-9]{3}-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8}|[0-9]{1,8})$"
            ERROR 2125 -->
            <xsl:when test="$tipoComprobante = '14' and cac:DiscrepancyResponse/cbc:ResponseCode != '10'">
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2414'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2125'"/>
                    <xsl:with-param name="node" select="cac:DiscrepancyResponse/cbc:ReferenceID"/>
                    <xsl:with-param name="regexp" select="'^([S][A-Z0-9]{3}-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8}|--[0-9]{1,8})$'"/>
                </xsl:call-template>                
            </xsl:when>
        </xsl:choose>
        
        <!-- 
        ===========================================================================================================================================
        
        Fin Datos de la Nota de credito
        
        ===========================================================================================================================================
        -->
        
        
        <!-- 
        ===========================================================================================================================================
        
        Datos del Emisor
        
        ===========================================================================================================================================
        -->
        
        <xsl:apply-templates select="cac:AccountingSupplierParty"/>
        
        <!-- 
        ===========================================================================================================================================
        
        Fin Datos del Emisor
        
        ===========================================================================================================================================
        --> 
        
        <!-- 
        ===========================================================================================================================================
        
        Datos del cliente o receptor
        
        ===========================================================================================================================================
        -->
        
        <xsl:apply-templates select="cac:AccountingCustomerParty">
            <xsl:with-param name="root" select="."/>
            <xsl:with-param name="tipoComprobante" select="$tipoComprobante"/>
        </xsl:apply-templates>
        
        <!-- 
        ===========================================================================================================================================
        
        fin Datos del cliente o receptor
        
        ===========================================================================================================================================
        -->
        
        <!-- 
        ===========================================================================================================================================
        
        Documentos de referencia
        
        ===========================================================================================================================================
        -->
        
        <xsl:apply-templates select="cac:BillingReference/cac:InvoiceDocumentReference">
            <xsl:with-param name="tipoComprobante" select="$tipoComprobante"/>
        </xsl:apply-templates>
        
        <xsl:apply-templates select="cac:DespatchDocumentReference"/>
        
        
        <!-- /CreditNote/cac:AdditionalDocumentReference/cbc:DocumentTypeCode Si "Código de tipo de nota de crédito" es 10 (Otros), existe más de un Tag UBL igual a "99" 
        OBSERV 2635 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2635'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="cac:DiscrepancyResponse/cbc:ResponseCode ='10' and count(cac:AdditionalDocumentReference/cbc:DocumentTypeCode[text()='99']) > 1" />
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
        
        <xsl:apply-templates select="cac:AdditionalDocumentReference">
            <xsl:with-param name="root" select="."/>
        </xsl:apply-templates>
        
        <!-- 
        ===========================================================================================================================================
        
        Documentos de referencia
        
        ===========================================================================================================================================
        -->
        
        <!-- 
        ===========================================================================================================================================
        
        Datos del detalle o Ítem de la Nota de credito
        
        ===========================================================================================================================================
        -->
        
        <xsl:apply-templates select="cac:CreditNoteLine">
            <xsl:with-param name="root" select="."/>
        </xsl:apply-templates>
        
        <!-- 
        ===========================================================================================================================================
        
        fin Datos del detalle o Ítem de la Nota de credito
        
        ===========================================================================================================================================
        -->
        
        <!-- 
        ===========================================================================================================================================
        
        Totales de la Nota de credito
        
        ===========================================================================================================================================
        -->
        <!-- /CreditNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation El Tag UBL no debe repetirse en el /CreditNote
        ERROR 2427 -->        
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2427'" />
            <xsl:with-param name="node" select="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation" />
            <xsl:with-param name="expresion" select="count(ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation) &gt; 1" />
        </xsl:call-template>
        
        
        <!-- /CreditNote/cac:LegalMonetaryTotal/cbc:ChargeTotalAmount    
        El formato del Tag UBL es diferente de decimal positivo de 12 enteros y hasta 2 decimales
        ERROR   2064
        -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeNotExist" select="'2064'"/>
            <xsl:with-param name="errorCodeValidate" select="'2064'"/>
            <xsl:with-param name="node" select="cac:LegalMonetaryTotal/cbc:ChargeTotalAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:LegalMonetaryTotal/cbc:PayableAmount
        El formato del Tag UBL es diferente de decimal positivo de 12 enteros y hasta 2 decimales
        ERROR   2062
         -->
        <xsl:call-template name="existAndValidateValueTwoDecimal">
            <xsl:with-param name="errorCodeNotExist" select="'2062'"/>
            <xsl:with-param name="errorCodeValidate" select="'2062'"/>
            <xsl:with-param name="node" select="cac:LegalMonetaryTotal/cbc:PayableAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:RequestedMonetaryTotal/cbc:PrepaidAmount Si existe el Tag UBL, el valor del Tag UBL es meno igual a 0 (cero) 
        OBSERV 2527 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2527'" />
            <xsl:with-param name="node" select="cac:RequestedMonetaryTotal/cbc:PrepaidAmount" />
            <xsl:with-param name="expresion" select="cac:RequestedMonetaryTotal/cbc:PrepaidAmount and cac:RequestedMonetaryTotal/cbc:PrepaidAmount &lt;= 0" />
            <xsl:with-param name="isError" select="false()"/>            
        </xsl:call-template>
        
        
        
        
        
        
        <!-- sac:AdditionalMonetaryTotal -->
        <xsl:apply-templates select="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal"/>
        
        <!-- Tributos duplicados por cabecera -->
        <xsl:apply-templates select="cac:TaxTotal/cac:TaxSubtotal" mode="cabecera"/>
        
        <!-- Tributos de la cabecera-->
        <xsl:apply-templates select="cac:TaxTotal" mode="cabecera">
            <xsl:with-param name="root" select="."/>
        </xsl:apply-templates>
        
        
        <!-- 
        ===========================================================================================================================================
        
        Fin Totales de la Nota de credito
        
        ===========================================================================================================================================
        -->
        
        <!-- Retornamos el comprobante al flujo necesario para lotes -->
        <xsl:copy-of select="."/>
        
    </xsl:template>
        
    <!-- 
    ===========================================================================================================================================
    *******************************************************************************************************************************************
                                                       TEMPLATES
    *******************************************************************************************************************************************
    ===========================================================================================================================================
    -->
    
    <!-- 
    ===========================================================================================================================================
    
    ============================================ Template cac:AccountingSupplierParty =========================================================
    
    ===========================================================================================================================================
    -->
    <xsl:template match="cac:AccountingSupplierParty">
    
        <!-- /CreditNote/cac:AccountingSupplierParty/cbc:AdditionalAccountID No existe el Tag UBL
        ERROR 1008 -->
        
        <!-- /CreditNote/cac:AccountingSupplierParty/cbc:AdditionalAccountID El Tag UBL es diferente a "6"
        ERROR 1007 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'1008'"/>
            <xsl:with-param name="errorCodeValidate" select="'1007'"/>
            <xsl:with-param name="node" select="cbc:AdditionalAccountID"/>
            <xsl:with-param name="regexp" select="'^(6)$'"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AccountingSupplierParty/cbc:AdditionalAccountID Existe más de un Tag UBL en el XML
        ERROR 2362 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2362'" />
            <xsl:with-param name="node" select="cbc:AdditionalAccountID" />
            <xsl:with-param name="expresion" select="count(cbc:AdditionalAccountID)>1" />
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName No existe el Tag UBL
        ERROR 1037 -->
        
        <!-- /CreditNote/cac:AccountingSupplierParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName El formato del Tag UBL es diferente a alfanumérico de hasta 1000 caracteres
        ERROR 1038 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'1037'"/>
            <xsl:with-param name="errorCodeValidate" select="'1038'"/>
            <xsl:with-param name="node" select="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>
            <xsl:with-param name="regexp" select="'^(?!\s*$)[^\s].{2,999}$'"/> <!-- de tres a 1000 caracteres que no inicie por espacio -->
        </xsl:call-template>
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:AccountingSupplierParty ======================================================
    
    ===========================================================================================================================================
    -->
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:AccountingCustomerParty =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:AccountingCustomerParty">
        <xsl:param name="root" select = "'-'" />
        <xsl:param name="tipoComprobante" select = "'-'" />
        
        <!-- /CreditNote/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID No existe el Tag UBL
        ERROR 2014 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2014'"/>
            <xsl:with-param name="node" select="cbc:CustomerAssignedAccountID"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AccountingCustomerParty/cbc:CustomerAssignedAccountID Si "Tipo de documento de identidad del adquiriente" es RUC (6), el formato del Tag UBL es diferente a numérico de 11 dígitos
        ERROR 2017 -->
        <xsl:if test="cbc:AdditionalAccountID ='6'">
            <xsl:call-template name="regexpValidateElementIfExist">
             <xsl:with-param name="errorCodeValidate" select="'2017'"/>
             <xsl:with-param name="node" select="cbc:CustomerAssignedAccountID"/>
             <xsl:with-param name="regexp" select="'^[\d]{11}$'"/>
         </xsl:call-template>
        </xsl:if>
        
        <!-- /CreditNote/cac:AccountingCustomerParty/cbc:AdditionalAccountID No existe el Tag UBL
        ERROR 2015 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2015'"/>
            <xsl:with-param name="node" select="cbc:AdditionalAccountID"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AccountingCustomerParty/cbc:AdditionalAccountID Si existe algún "Afectación al IGV por la línea" igual a 40 (Exportación) o la Serie del comprobante empieza con "B", el Tag UBL es diferente al listado o guión "-"
        ERROR 2016 -->
<!--         <xsl:choose>
            <xsl:when test="$root/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode[text() ='40'] or $tipoComprobante ='03' or $tipoComprobante ='14'">
                
                <xsl:if test="cbc:AdditionalAccountID or cbc:AdditionalAccountID != '-'">
                    <xsl:call-template name="findElementInCatalog">
                        <xsl:with-param name="catalogo" select="'06'"/>
                        <xsl:with-param name="idCatalogo" select="cbc:AdditionalAccountID"/>
                        <xsl:with-param name="errorCodeValidate" select="'2016'"/>
                    </xsl:call-template>
                </xsl:if>
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="regexpValidateElementIfExist">
                    <xsl:with-param name="errorCodeValidate" select="'2016'"/>
                    <xsl:with-param name="node" select="cbc:AdditionalAccountID"/>
                    <xsl:with-param name="regexp" select="'^6$'"/>
                </xsl:call-template>
            </xsl:otherwise>
        </xsl:choose> -->
		
		
        <!-- Ajuste Pase81 jas300418 /CreditNote/cac:AccountingCustomerParty/cbc:AdditionalAccountID el Tag es diferente al catalogo 6 - ERROR 2016 -->
		
                <xsl:call-template name="regexpValidateElementIfExist">
                    <xsl:with-param name="errorCodeValidate" select="'2016'"/>
                    <xsl:with-param name="node" select="cbc:AdditionalAccountID"/>
                    <xsl:with-param name="regexp" select="'^[01467ABCDE\-]$'"/>
                </xsl:call-template>
	   
        <!-- /CreditNote/cac:AccountingCustomerParty/cbc:AdditionalAccountID Existe más de un Tag UBL en el XML
        ERROR 2363 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2363'" />
            <xsl:with-param name="node" select="cbc:AdditionalAccountID" />
            <xsl:with-param name="expresion" select="count(cbc:AdditionalAccountID)>1" />
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName No existe el Tag UBL
        ERROR 2021 -->
        
        <!-- /CreditNote/cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity/cbc:RegistrationName El formato del Tag UBL es diferente a alfanumérico de 3 hasta 1000 caracteres
        ERROR 2022 --> 
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2021'"/>
            <xsl:with-param name="errorCodeValidate" select="'2022'"/>
            <xsl:with-param name="node" select="cac:Party/cac:PartyLegalEntity/cbc:RegistrationName"/>
            <xsl:with-param name="regexp" select="'^(?!\s*$)[^\s].{2,999}$'"/> <!-- de tres a 1000 caracteres que no inicie por espacio -->
            <!-- Ini PAS20171U210300071 -->
			<xsl:with-param name="isError" select ="false()"/>
			<!-- Fin PAS20171U210300071 -->
        </xsl:call-template>
        
        <!--  Si "Tipo de operación" es 13 y el "Tipo de documento de identidad del adquiriente o usuario" es 1, el formato del Tag UBL es diferente de numérico de 8 dígitos 
        ERROR 2801 -->
        <xsl:if test="cbc:AdditionalAccountID ='1'">
            <xsl:call-template name="regexpValidateElementIfExist">
                <xsl:with-param name="errorCodeValidate" select="'2801'"/>
                <xsl:with-param name="node" select="cbc:CustomerAssignedAccountID"/>
                <xsl:with-param name="regexp" select="'^[\d]{8}$'"/>
            </xsl:call-template>
        </xsl:if>
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:AccountingCustomerParty =========================================== 
    
    ===========================================================================================================================================
    -->
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:BillingReference/cac:InvoiceDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:BillingReference/cac:InvoiceDocumentReference">
        <xsl:param name="tipoComprobante" select = "'-'" />
        
        <xsl:choose>
            
            <xsl:when test="$tipoComprobante ='01'">
                <!-- /CreditNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID "Si la nota de credito modifica una Factura, la serie debe iniciar con F. 
                Si la ND modifica a una factura (tipo de comprobante =01), y el formato del Tag UBL es diferente a: ^([F][A-Z0-9]{3}-[0-9]{1,8}|(E001)-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8})$"
                ERROR 2117 -->
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2117'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2117'"/>
                    <xsl:with-param name="node" select="cbc:ID"/>
                    <xsl:with-param name="regexp" select="'^(([F][A-Z0-9]{3}-[0-9]{1,8})|((E001)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8}))$'"/>
                </xsl:call-template>
                
                <!-- /CreditNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:DocumentTypeCode Si la Serie del comprobante empieza con "F", el Tag UBL es diferente de "01", "12", "56"
                ERROR 2116 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2116'" />
                    <xsl:with-param name="node" select="cbc:DocumentTypeCode" />
                    <xsl:with-param name="expresion" select="cbc:DocumentTypeCode[text() !='01' and text() !='12' and text() !='56']" />
                </xsl:call-template>
            </xsl:when>
            
                
            <xsl:when test="$tipoComprobante ='03'">
                <!-- /CreditNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID "Si la nota de credito modifica una Boleta de venta, la serie debe iniciar con B. 
                Si la NC modifica a una boleta de venta (tipo de comprobante =03), y el formato del Tag UBL es diferente a:^([B][A-Z0-9]{3}-[0-9]{1,8}|(EB01)-[0-9]{1,8}|[0-9]{1,4}-[0-9]{1,8})$"
                ERROR 2117 -->
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2117'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2117'"/>
                    <xsl:with-param name="node" select="cbc:ID"/>
                    <xsl:with-param name="regexp" select="'^(([B][A-Z0-9]{3}-[0-9]{1,8})|((EB01)-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8}))$'"/>
                </xsl:call-template>
                
                <!-- /CreditNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:DocumentTypeCode Si la Serie del comprobante empieza con "B", el Tag UBL es diferente de "03"
                ERROR 2399 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2399'" />
                    <xsl:with-param name="node" select="cbc:DocumentTypeCode" />
                    <xsl:with-param name="expresion" select="cbc:DocumentTypeCode != '03'" />
                </xsl:call-template>
                
            </xsl:when>
            
            
            <xsl:when test="$tipoComprobante ='14'">
                
                <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2205'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2205'"/>
                    <xsl:with-param name="node" select="cbc:ID"/>
                    <xsl:with-param name="regexp" select="'^(([S][A-Z0-9]{3}-[0-9]{1,8})|([0-9]{1,4}-[0-9]{1,8})|(--[0-9]{1,8}))$'"/>
                </xsl:call-template>
                
                <!-- /CreditNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:DocumentTypeCode Si la Serie del comprobante empieza con "S", el Tag UBL es diferente de "14"
                ERROR 2399 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2991'" />
                    <xsl:with-param name="node" select="cbc:DocumentTypeCode" />
                    <xsl:with-param name="expresion" select="cbc:DocumentTypeCode != '14'" />
                </xsl:call-template>
                
            </xsl:when>
            <!-- /CreditNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID "Si ""Tipo del documento del documento que modifica"" es ""12"", 
            el formato del Tag UBL es diferente a:^([a-zA-Z0-9-]{1,20}-[0-9]{1,10})$"
            ERROR 2117 -->
            <xsl:when test="cbc:DocumentTypeCode='12'">
               <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2117'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2117'"/>
                    <xsl:with-param name="node" select="cbc:ID"/>
                    <xsl:with-param name="regexp" select="'^([a-zA-Z0-9-]{1,20}-[0-9]{1,10})$'"/>
                </xsl:call-template>
            </xsl:when>
            
            <!-- /CreditNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID Si "Tipo del documento del documento que modifica" es "56", 
            el valor del Tag UBL es alfanumérico
            ERROR 2117 -->
            <xsl:when test="cbc:DocumentTypeCode='56'">
               <xsl:call-template name="existAndRegexpValidateElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2117'"/>
                    <xsl:with-param name="errorCodeValidate" select="'2117'"/>
                    <xsl:with-param name="node" select="cbc:ID"/>
                    <xsl:with-param name="regexp" select="'^[\w\d\- ]+$'"/>
                </xsl:call-template>
            </xsl:when>
                    
        </xsl:choose>
        
        <!-- /CreditNote/cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID El "Tipo de documento del documento que modifica" concatenado con el valor del Tag UBL no debe repetirse en el /CreditNote
        ERROR 2365 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2365'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-Billingreference', concat(cbc:DocumentTypeCode, cbc:ID))) > 1" />
        </xsl:call-template>
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:BillingReference/cac:InvoiceDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:DespatchDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:DespatchDocumentReference">
    
        <!-- /CreditNote/cac:DespatchDocumentReference/cbc:ID "Si el Tag UBL existe, el formato del Tag UBL es diferente a: ^([T][0-9]{3}-[0-9]{1,8}|[0-9]{4}-[0-9]{1,8}|[E][G][0-9]{2}-[0-9]{1,8}|[G][0-9]{3}-[0-9]{1,8})$" 
        OBSERV 4006 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'4006'"/>
            <xsl:with-param name="errorCodeValidate" select="'4006'"/>
            <xsl:with-param name="node" select="cbc:ID"/>
            <xsl:with-param name="regexp" select="'^(([T][0-9]{3}-[0-9]{1,8})|([0-9]{4}-[0-9]{1,8})|([E][G][0-9]{2}-[0-9]{1,8})|([G][0-9]{3}-[0-9]{1,8}))$'"/>
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
        
        <!-- /CreditNote/cac:DespatchDocumentReference/cbc:ID El "Tipo de la guía de remisión relacionada" concatenado con el valor del Tag UBL no debe repetirse en el /CreditNote
        ERROR 2364 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2364'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-document-despatch-reference', concat(cbc:DocumentTypeCode,' ',cbc:ID))) > 1" />
        </xsl:call-template>
        
        <!-- /CreditNote/cac:DespatchDocumentReference/cbc:DocumentTypeCode Si existe el Tag UBL, el formato del Tag UBL es diferente de "09" o "31" 
        OBSERV 4005 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'4005'"/>
            <xsl:with-param name="errorCodeValidate" select="'4005'"/>
            <xsl:with-param name="node" select="cbc:DocumentTypeCode"/>
            <xsl:with-param name="regexp" select="'^(31)|(09)$'"/>
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
    
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:DespatchDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:AdditionalDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:AdditionalDocumentReference">
        <xsl:param name="root"/>
    
        <!-- /CreditNote/cac:AdditionalDocumentReference/cbc:ID El formato del Tag UBL es diferente a alfanumérico de entre 6 y 30 caracteres (letras, números y guión) 
        OBSERV 4010 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'4010'"/>
            <xsl:with-param name="errorCodeValidate" select="'4010'"/>
            <xsl:with-param name="node" select="cbc:ID"/>
            <xsl:with-param name="regexp" select="'^(?!\s*$)[^\s]{6,30}$'"/>
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AdditionalDocumentReference/cbc:ID El "Tipo de otro documento relacionado" concatenado con el valor del Tag UBL, no debe repetirse en el /CreditNote
        ERROR 2426 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2426'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-document-additional-reference', concat(cbc:DocumentTypeCode,' ',cbc:ID))) > 1" />
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AdditionalDocumentReference/cbc:ID Si "Código de tipo de nota de crédito" es diferente de 10 (Otros) y "Tipo de otro documento relacionado" es 99, el Tag UBL es vacío 
        OBSERV 2636 -->
        <xsl:variable name="tipoNota" select="$root/cac:DiscrepancyResponse/cbc:ResponseCode"/>
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2636'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="$tipoNota != '10' and cbc:DocumentTypeCode ='99' and not(string(cbc:ID))" />
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AdditionalDocumentReference/cbc:DocumentType Si "Código de tipo de nota de crédito" es  10 (Otros) y "Tipo de otro documento relacionado"es 99, no existe el Tag UBL o es vacío 
        OBSERV 2637 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2637'" />
            <xsl:with-param name="node" select="cbc:DocumentType" />
            <xsl:with-param name="expresion" select="$tipoNota != '10' and cbc:DocumentTypeCode ='99' and not(string(cbc:DocumentType))" />
            <xsl:with-param name="isError" select ="false()"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:AdditionalDocumentReference/cbc:DocumentTypeCode El formato del Tag UBL es diferente de "04" o "05" o "99" o "01"
        ERROR 4009 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'4009'"/>
            <xsl:with-param name="errorCodeValidate" select="'4009'"/>
            <xsl:with-param name="node" select="cbc:DocumentTypeCode"/>
            <xsl:with-param name="regexp" select="'^(0[145]|99)$'"/>
            <!--xsl:with-param name="isError" select ="false()"/ -->
        </xsl:call-template>
        
        
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:AdditionalDocumentReference =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:CreditNoteLine =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:CreditNoteLine">
    
        <xsl:param name="root"/>
        
        <xsl:variable name="nroLinea" select="cbc:ID"/>
        
        <xsl:variable name="tipoOperacion" select="$root/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:SUNATTransaction/cbc:ID"/>
        
        <xsl:variable name="codigoPrecio" select="cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode"/>
        
        <!-- /CreditNote/cac:CreditNoteLine/cbc:ID El formato del Tag UBL es diferente de numérico de 3 dígitos
        ERROR 2137 -->
        <xsl:call-template name="existAndRegexpValidateElement">
            <xsl:with-param name="errorCodeNotExist" select="'2137'"/>
            <xsl:with-param name="errorCodeValidate" select="'2137'"/>
            <xsl:with-param name="node" select="cbc:ID"/>
            <xsl:with-param name="regexp" select="'^(?!0*$)\d{1,3}$'"/> <!-- de tres numeros como maximo, no cero -->
            <xsl:with-param name="descripcion" select="concat('Error en la linea:', position(), '. ')"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:CreditNoteLine/cbc:ID El valor del Tag UBL no debe repetirse en el /CreditNote
        ERROR 2752 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2752'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-invoiceLine-id', number(cbc:ID))) > 1" />
            <xsl:with-param name="descripcion" select="concat('Error en la linea:', position(), '. ')"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:CreditNoteLine/cbc:CreditedQuantity/@unitCode Si el Tag UBL existe, no existe el atributo del Tag UBL
        ERROR 2138 -->
        <xsl:if test="cbc:CreditedQuantity">
            <xsl:call-template name="existElement">
                <xsl:with-param name="errorCodeNotExist" select="'2138'"/>
                <xsl:with-param name="node" select="cbc:CreditedQuantity/@unitCode"/>
                <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
            </xsl:call-template>
        </xsl:if>
        
        <!-- /CreditNote/cac:CreditNoteLine/cbc:CreditedQuantity Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 10 decimales
        ERROR 2139 -->
<!--         <xsl:call-template name="validateValueTenDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2139'"/>
            <xsl:with-param name="node" select="cbc:CreditedQuantity"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>			
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template> -->
		
		
		<!-- PAS20181U210300051 jas 090718 -->		
        <!-- /CreditNote/cac:CreditNoteLine/cbc:CreditedQuantity Si el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 10 decimales ERROR 2189, incluye ceros al comienzo -->		
		<xsl:call-template name="regexpValidateElementIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2139'"/>
            <xsl:with-param name="node" select="cbc:CreditedQuantity"/>
			<xsl:with-param name="regexp" select="'^[0-9\s]{1,12}(\.[0-9\s]{1,10})?'"/>
			<xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>	


        
        <!-- /CreditNote/cac:CreditNoteLine/cac:Price/cbc:PriceAmount Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 10 decimales
        ERROR 2369 -->
        <xsl:call-template name="validateValueTenDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2369'"/>
            <xsl:with-param name="node" select="cac:Price/cbc:PriceAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 10 decimales
        ERROR 2367 -->
        <xsl:call-template name="validateValueTenDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2367'"/>
            <xsl:with-param name="node" select="cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode Si el Tag UBL existe, el valor del Tag UBL es diferente al Catálogo 16
        ERROR 2410 -->
        <xsl:for-each select="cac:PricingReference/cac:AlternativeConditionPrice">
            <!-- /DebitNote/cac:CreditNoteLine/cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode Si el Tag UBL existe, el valor del Tag UBL es diferente al Catálogo 16
            ERROR 2410 -->
            <xsl:call-template name="findElementInCatalog">
                <xsl:with-param name="catalogo" select="'16'"/>
                <xsl:with-param name="idCatalogo" select="cbc:PriceTypeCode"/>
                <xsl:with-param name="errorCodeValidate" select="'2410'"/>
                <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
            </xsl:call-template>
            
        </xsl:for-each>
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode El valor del Tag UBL no debe repertirse en el /CreditNote/cac:CreditNoteLine/cac:PricingReference/cac:AlternativeConditionPrice
        ERROR 2409 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2409'" />
            <xsl:with-param name="node" select="cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode" />
            <xsl:with-param name="expresion" select="(count(cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode[text()='01'])>1 or count(cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceTypeCode[text()='02'])>1)" />
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:PricingReference/cac:AlternativeConditionPrice/cbc:PriceAmount Si "Afectación al IGV por línea" es 10 (Gravado), 20 (Exonerado) o 30 (Inafecto) y "Código de precio" es 02 (Valor referencial en operaciones no onerosa), el Tag UBL es mayor a 0 (cero)
        ERROR 2425 -->
        <xsl:if test="$codigoPrecio='02'">
            <xsl:call-template name="isTrueExpresion">
                <xsl:with-param name="errorCodeValidate" select="'2425'" />
                <xsl:with-param name="node" select="cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode" />
                <xsl:with-param name="expresion" select="cac:PricingReference/cac:AlternativeConditionPrice[cbc:PriceTypeCode ='02']/cbc:PriceAmount > 0 and cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode[text() = '10' or text() = '20' or text() = '30']" />
                <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
            </xsl:call-template>
            
        </xsl:if>
        <!-- /CreditNote/cac:CreditNoteLine/cbc:LineExtensionAmount El formato del Tag UBL es diferente de decimal (positivo o negativo) de 12 enteros y hasta 2 decimales
        ERROR 2370 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2370'"/>
            <xsl:with-param name="node" select="cbc:LineExtensionAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- Tributos por linea de detalle -->
        <xsl:apply-templates select="cac:TaxTotal" mode="linea">
            <xsl:with-param name="nroLinea" select="$nroLinea"/>
            <xsl:with-param name="root" select="$root"/>
        </xsl:apply-templates>
        
        <!-- Tributos duplicados por linea -->
        <xsl:apply-templates select="cac:TaxTotal/cac:TaxSubtotal" mode="linea">
           <xsl:with-param name="nroLinea" select="$nroLinea"/>
        </xsl:apply-templates>
          
    </xsl:template>
    
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:CreditNoteLine =========================================== 
    
    ===========================================================================================================================================
    -->
    
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:TaxTotal/cac:TaxSubtotal =========================================== 
    
    ===========================================================================================================================================
    -->        
    <xsl:template match="cac:TaxTotal/cac:TaxSubtotal" mode="linea">
        <xsl:param name="nroLinea"/>
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID El valor del Tag UBL no debe repetirse en el /CreditNote/cac:CreditNoteLine
        ERROR 2355 -->
        
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2355'" />
            <xsl:with-param name="node" select="cac:TaxCategory/cac:TaxScheme/cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-tributos-in-line', concat(cac:TaxCategory/cac:TaxScheme/cbc:ID,'-', $nroLinea))) > 1" />
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
      
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:TaxTotal/cac:TaxSubtotal =========================================== 
    
    ===========================================================================================================================================
    -->    
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:TaxTotal =========================================== 
    
    ===========================================================================================================================================
    -->
    <xsl:template match="cac:TaxTotal" mode="linea">
        <xsl:param name="nroLinea"/>
        <xsl:param name="root"/>
        
        <xsl:variable name="tipoOperacion" select="$root/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:SUNATTransaction/cbc:ID"/>
        
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cbc:TaxAmount Si el Tag UBL existe, el Tag UBL es diferente al Tag anterior
        ERROR 2372 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2372'" />
            <xsl:with-param name="node" select="cbc:TaxAmount" />
            <xsl:with-param name="expresion" select="number(cac:TaxSubtotal/cbc:TaxAmount) != number(cbc:TaxAmount)" />
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID Si el Tag UBL existe, el valor del Tag UBL es diferente al listado
        ERROR 2036 -->
        <xsl:call-template name="findElementInCatalog">
            <xsl:with-param name="catalogo" select="'05'"/>
            <xsl:with-param name="idCatalogo" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
            <xsl:with-param name="errorCodeValidate" select="'2036'"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name No existe el Tag UBL
        ERROR 2195 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2195'"/>
            <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cbc:TaxAmount Si el Tag UBL existe, el formato del Tag UBL es diferente de decimal de 12 enteros y hasta 2 decimales
        ERROR 2033 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2033'"/>
            <xsl:with-param name="node" select="cbc:TaxAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
            <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
        </xsl:call-template>
        
        <xsl:choose>
            <xsl:when test="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID = '1000'">
        
                <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode Si "Código de tributo por línea" es 1000 (IGV), no existe el Tag UBL
                ERROR 2371 -->
                <xsl:call-template name="existElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2371'"/>
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode"/>
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                
                
                <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name Si "Código de tributo por línea" es 1000 (IGV), el valor del Tag UBL es diferente de "IGV"
                ERROR 2377 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2377'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:Name != 'IGV'" />
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea, '. cbc:Name debe de ser IGV')"/>
                    <!-- Ini PAS20171U210300071 -->
					<xsl:with-param name="isError" select ="false()"/>
					<!-- Fin PAS20171U210300071 -->
                </xsl:call-template>
                
                <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode Si "Código de tributo por línea" es 1000, el valor del Tag UBL es diferente al código internacional del listado para el "Código de tributo por línea" 
                ERROR 2377 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2377'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:TaxTypeCode != 'VAT'" />
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea, '. cbc:TaxTypeCode debe ser VAT')"/>
                    <!-- Ini PAS20171U210300071 -->
					<xsl:with-param name="isError" select ="false()"/>
					<!-- Fin PAS20171U210300071 -->
                </xsl:call-template>
                
                <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode Si "Código de tributo por línea" es 1000 (IGV), el valor del Tag UBL es diferente al Catálogo 7
                ERROR 2145 -->
                <xsl:call-template name="findElementInCatalog">
                    <xsl:with-param name="catalogo" select="'07'"/>
                    <xsl:with-param name="idCatalogo" select="cac:TaxSubtotal/cac:TaxCategory/cbc:TaxExemptionReasonCode"/>
                    <xsl:with-param name="errorCodeValidate" select="'2145'"/>
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
        
            </xsl:when>
        
            <xsl:when test="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID = '2000'">
            
            
                <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TierRange Si "Código de tributo por línea" es 2000 (ISC), no existe el Tag UBL
                ERROR 2373 -->
                <xsl:call-template name="existElement">
                    <xsl:with-param name="errorCodeNotExist" select="'2373'"/>
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cbc:TierRange"/>
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cbc:TierRange Si "Código de tributo por línea" es 2000 (ISC), el valor del Tag UBL es diferente al listado
                ERROR 2199 -->
                <xsl:call-template name="findElementInCatalog">
                    <xsl:with-param name="catalogo" select="'08'"/>
                    <xsl:with-param name="idCatalogo" select="cac:TaxSubtotal/cac:TaxCategory/cbc:TierRange"/>
                    <xsl:with-param name="errorCodeValidate" select="'2199'"/>
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name Si "Código de tributo por línea" es 2000 (ISC), el valor del Tag UBL es diferente de "ISC"
                ERROR 2378 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2378'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:Name != 'ISC'" />
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
                <!-- /CreditNote/cac:CreditNoteLine/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode Si "Código de tributo por línea" es 2000, el valor del Tag UBL es diferente al código internacional del listado para el "Código de tributo por línea" 
                ERROR 2378 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2378'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:TaxTypeCode != 'EXC'" />
                    <xsl:with-param name="descripcion" select="concat('Error en la linea: ', $nroLinea)"/>
                </xsl:call-template>
                
            </xsl:when>
           
        </xsl:choose>
        
    </xsl:template>
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:TaxTotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
    
    <!-- 
    ===========================================================================================================================================
    
    ========== Template ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal =========
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal">
    
<!-- /CreditNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal/cbc:ID El valor del Tag UBL es diferente a 1001, 1002, 1003, 1004, 2001, 2005
        ERROR 2150 -->        
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2150'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="not(cbc:ID[text()='1001' or text()='1002' or text()='1003' or text()='1004' or text()='2001' or text()='2005'])" />
        </xsl:call-template>
        
        <!-- /CreditNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal/cbc:ID El valor del Tag UBL no debe repetirse en el /CreditNote
        ERROR 2406 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2406'" />
            <xsl:with-param name="node" select="cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-AdditionalMonetaryTotal', cbc:ID)) > 1" />
        </xsl:call-template>
        
        <!-- /CreditNote/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal/cbc:PayableAmount El formato del Tag UBL es diferente de decimal de 12 enteros y hasta 2 decimales
        ERROR 2149 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeNotExist" select="'2149'"/>
            <xsl:with-param name="errorCodeValidate" select="'2149'"/>
            <xsl:with-param name="node" select="cbc:PayableAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
        </xsl:call-template>
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    ======== Fin Template ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:AdditionalMonetaryTotal =========
    
    ===========================================================================================================================================
    -->
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:TaxTotal/cac:TaxSubtotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:TaxTotal/cac:TaxSubtotal" mode="cabecera">
        <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID El valor del Tag UBL no debe repetirse en el /CreditNote
        ERROR 2352 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2352'" />
            <xsl:with-param name="node" select="cac:TaxCategory/cac:TaxScheme/cbc:ID" />
            <xsl:with-param name="expresion" select="count(key('by-tributos-in-root', cac:TaxCategory/cac:TaxScheme/cbc:ID)) > 1" />
        </xsl:call-template>     
        
      
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:TaxTotal/cac:TaxSubtotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
    
<!-- 
    ===========================================================================================================================================
    
    =========================================== Template cac:TaxTotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
    <xsl:template match="cac:TaxTotal" mode="cabecera">
        
        <xsl:param name="root"/>
        
        <xsl:variable name="tipoOperacion" select="$root/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent/sac:AdditionalInformation/sac:SUNATTransaction/cbc:ID"/>
        
        <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID No existe el Tag UBL
        ERROR 2052 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2052'"/>
            <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID El valor del Tag UBL es diferente al listado
        ERROR 2051 -->
        <xsl:call-template name="findElementInCatalog">
            <xsl:with-param name="catalogo" select="'05'"/>
            <xsl:with-param name="idCatalogo" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID"/>
            <xsl:with-param name="errorCodeValidate" select="'2051'"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name No existe el Tag UBL
        ERROR 2054 -->
        <xsl:call-template name="existElement">
            <xsl:with-param name="errorCodeNotExist" select="'2054'"/>
            <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name"/>
        </xsl:call-template>
        
        <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cbc:TaxAmount El Tag UBL es diferente al Tag anterior
        ERROR 2061 -->
        <xsl:call-template name="isTrueExpresion">
            <xsl:with-param name="errorCodeValidate" select="'2061'" />
            <xsl:with-param name="node" select="cbc:TaxAmount" />
            <xsl:with-param name="expresion" select="number(cac:TaxSubtotal/cbc:TaxAmount) != number(cbc:TaxAmount)" />
        </xsl:call-template>
        
        <!-- /CreditNote/cac:TaxTotal/cbc:TaxAmount El formato del Tag UBL es diferente de decimal de 12 enteros y hasta 2 decimales
        ERROR 2048 -->
        <xsl:call-template name="validateValueTwoDecimalIfExist">
            <xsl:with-param name="errorCodeValidate" select="'2048'"/>
            <xsl:with-param name="node" select="cbc:TaxAmount"/>
            <xsl:with-param name="isGreaterCero" select="false()"/>
        </xsl:call-template>
        
        <xsl:choose>
            <xsl:when test="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID = '1000'">
                <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name Si "Código de tributo" es 1000 (IGV), el valor del Tag UBL es diferente de "IGV"
                ERROR 2057 -->
                
                <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode Si "Código de tributo" es 1000 (IGV), el valor del Tag UBL es diferente al código internacional del listado para el "Código de tributo"
                ERROR 2057 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2057'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:Name[text() != 'IGV']
                        or
                        cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '1000']/cbc:TaxTypeCode[text() != 'VAT']" />
                </xsl:call-template>
            </xsl:when>
            
            <xsl:when test="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID = '2000'">
                <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:Name Si "Código de tributo" es 2000 (ISC), el valor del Tag UBL es diferente de "ISC"
                ERROR 2058 -->
                
                <!-- /CreditNote/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode Si "Código de tributo" es 2000 (ISC), el valor del Tag UBL es diferente de "ISC"
                ERROR 2058 -->
                <xsl:call-template name="isTrueExpresion">
                    <xsl:with-param name="errorCodeValidate" select="'2058'" />
                    <xsl:with-param name="node" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme/cbc:ID" />
                    <xsl:with-param name="expresion" select="cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:Name[text() != 'ISC']
                        or
                        cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme[cbc:ID = '2000']/cbc:TaxTypeCode[text() != 'EXC']" />
                </xsl:call-template>
            </xsl:when>
        
        </xsl:choose>
      
    </xsl:template>
    
    <!-- 
    ===========================================================================================================================================
    
    =========================================== fin Template cac:TaxTotal =========================================== 
    
    ===========================================================================================================================================
    -->
    
   
</xsl:stylesheet>